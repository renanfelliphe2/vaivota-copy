import Image from "next/image";

export default function Home() {
  return (
    <div className="flex flex-col flex-1 items-center justify-center bg-zinc-50 font-sans dark:bg-black">
      <main className="flex flex-1 w-full max-w-3xl flex-col items-center py-32 px-16 bg-white dark:bg-black sm:items-start">
        <Image
          className="dark:invert h-5 w-[100px]"
          src="/next.svg"
          alt="Next.js logo"
          width={100}
          height={20}
          priority
        />
        <div className="flex flex-col items-center gap-6 text-center sm:items-start sm:text-left">
          <h1 className="w-full text-3xl mt-5 font-semibold leading-10 tracking-tight text-black dark:text-zinc-50">
             Projeto Ver e Fazer Filmes
          </h1>
          <p className="max-w-md text-lg leading-8 text-zinc-600 dark:text-zinc-400">
            Uma plataforma web de votação e apoio à experiência do público do
            <a href="https://festivalverefazerfilmes.org.br/" className="font-medium text-zinc-950 dark:text-zinc-50" >
              &nbsp;9º Festival Ver e Fazer Filmes
            </a>
            , oferecendo uma experiência visual e interativa para o concurso de curtas-metragens.
          </p>
        </div>
      </main>
    </div>
  );
}
